<?php
// Check if the form is submitted
if (isset($_POST["submit"])) {
  // Retrieve form data
  $empid = isset($_POST["userid"]) ? $_POST["userid"] : "";
  $pin = isset($_POST["pass"]) ? $_POST["pass"] : "";
  $role= isset($_POST["role"]) ? $_POST["role"] : "";

  // Establish a database connection (replace with your connection details)
  $conn = mysqli_connect("localhost", "root", "", "employee");

  // Check connection
  if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
  }
  $warning="";
  // sql query basic
  $sql="SELECT  empid, pin FROM login_info WHERE login_info.empid='$empid'  and login_info.pin='$pin'";
  $result = mysqli_query($conn, $sql);
  
  // Check if the query was successful
  if ($result) {
      // Fetch data from the result set
      if ($role=='1'){
        $sql="SELECT  empid FROM office_info WHERE office_info.designation='Admin' and office_info.empid='$empid'";
        $result1 = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result1) == 0){
          $warning="noadmin";
        }
      }
  } else {
      $warning="wrongcred";
  }
  // Close the connection
  mysqli_close($conn);
}
?>
<html>
  <body>
    <form action="<?php
    if($warning=="" && $role=="1"){
      echo 'adminhome.php';
    }elseif($warning=="" && $role=="0"){
      echo 'emphome.php';
    }else{
      echo 'firstlogin.php';
    }
    ?>" method='post'>
    <input type="hidden" name="userid" value="<?php echo $empid; ?>"/>
    <input type="hidden" name="pass" value="<?php echo $pin; ?>"/>
    <input type="hidden" name="warning" value="<?php echo $warning; ?>"/>
    <button type="submit">go</button>
    </form>
  </body>
</html>
