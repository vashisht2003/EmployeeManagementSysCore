<html>
    <body>
        <form action="<?php
        if(isset($_POST['submit'])){
          if($_POST['option'] == '1'){
            echo '1.php';
          } elseif ($_POST['option'] == '2') {
            echo '2.php';
          }
        }
      ?>" method="post">
            <select name="option" id="">
            <option value="1">1</option>
            <option value="2">2</option>
            </select>
            <button type="submit">submit</button>
            </form>            
    </body>
</html>