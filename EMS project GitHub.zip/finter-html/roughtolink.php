<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/fevicon.png" type="image/x-icon">
  <title>Login Page</title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
  <!-- nice select -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/css/nice-select.min.css"
    integrity="sha256-mLBIhmBvigTFWPSCtvdu6a76T+3Xyt+K571hupeFLg4=" crossorigin="anonymous" />
  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>
<body>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve values from the POST parameters
        $username = isset($_POST["userid"]) ? $_POST["userid"] : "";
        $password = isset($_POST["pass"]) ? $_POST["pass"] : "";
        $role = isset($_POST["role"]) ? $_POST["role"] : "";

        // Establish a database connection (replace with your connection details)
        $conn = mysqli_connect("localhost", "root", "", "practice");

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        if($role=="1"){
            // if admin 
            $sql = "SELECT * FROM admins,student WHERE admins.roll=$password and student.roll=admins.roll and name='$username'";
            $result = mysqli_query($conn, $sql);
            // Check if a record is found
        if (mysqli_num_rows($result) > 0) {
            // Set action to rough.php
            $action = "adminhome.php";
        } else {
            // Set action to empdash.php
            $action = "firstlogin.php";
        }
        }else{
            // if employee
            $sql = "SELECT * FROM student WHERE roll=$password and name='$username'";
            $result = mysqli_query($conn, $sql);
            // Check if a record is found
        if (mysqli_num_rows($result) > 0) {
            // Set action to rough.php
            $action = "emphome.php";
        } else {
            // Set action to empdash.php
            $action = "firstlogin.php";
        }
        }
        

        // Check if a record is found
        if (mysqli_num_rows($result) > 0) {
            // Set action to rough.php
            $action = "rough.php";
        } else {
            // Set action to empdash.php
            $action = "empdash.php";
        }


        // Close the connection
        mysqli_close($conn);

        // Display the received data on the webpage
        echo "<h2>User Information:</h2>";
        echo "<p><strong>Username:</strong> $username</p>";
        echo "<p><strong>Password:</strong> $password</p>";
        echo "<p><strong>Role:</strong> $role</p>";
    } else {
        echo "<p>No data received.</p>";
    }
    ?>
    <h1>dwhvbejfdvbswbfejk</h1>
</body>

</html>